// ==UserScript==
// @name         cliqRingTone
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Mr.G
// @match        http://*/*
// @icon         https://raw.githubusercontent.com/gowthamml/cliqRingTone/main/1641657985595__01.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    window.onload = function() {
        setRingTone();
    };
    var setRingTone = function(){
        if(typeof Sound != "undefined"){
            var audioElem = document.createElement("audio");
            audioElem.src = "https://github.com/gowthamml/cliqRingTone/blob/main/bodhai-kaname.mp3?raw=true";
            audioElem.preload = "auto";
            Sound.custom.cache.incomingmediacall = audioElem;
            Sound.custom.cache.INCOMING_TONE = audioElem;
            console.log('%c RINGTONE SET SUCCESSFULLY ','color:cyan;font-size:30px;');
        }else{
            setTimeout(setRingTone,2000);
            console.log('%c RETRYING SETTING RINGTONE ','color:orange;font-size:20px;');
        }
    }
    })();